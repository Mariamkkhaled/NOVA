package com.example.finalclient;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Client extends Application {

    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 8880;

    private BufferedReader input;
    private PrintWriter output;

    private VBox loginBox;
    private VBox signupBox;
    private VBox chatBox;
    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        try {
            // Connect to the server
            Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
            System.out.println("Connected to the server!");

            // Set up communication streams
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            output = new PrintWriter(socket.getOutputStream(), true);

            // Create the login, signup, and chat views
            loginBox = createLoginBox();
            signupBox = createSignupBox();
            chatBox = createChatBox();

            // Create the initial choice view
            VBox choiceBox = createChoiceBox();

            Scene scene = new Scene(choiceBox, 300, 200);

            // Set up the stage
            primaryStage.setScene(scene);
            primaryStage.setTitle("Login or Signup");
            primaryStage.show();
        } catch (IOException e) {
            System.err.println("Error connecting to the server: " + e.getMessage());
        }
    }

    private VBox createChoiceBox() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(20));

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(loginBox, 300, 200));
            primaryStage.setTitle("Login");
        });

        Button signupButton = new Button("Signup");
        signupButton.setOnAction(e -> {
            primaryStage.setScene(new Scene(signupBox, 300, 250));
            primaryStage.setTitle("Signup");
        });

        vbox.getChildren().addAll(loginButton, signupButton);
        return vbox;
    }

    private VBox createLoginBox() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(20));

        // Add login UI elements
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> handleLogin(usernameField.getText(), passwordField.getText()));

        vbox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, loginButton);
        return vbox;
    }

    private VBox createSignupBox() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(20));

        // Add signup UI elements
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();

        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();

        Button signupButton = new Button("Signup");
        signupButton.setOnAction(e -> handleSignup(usernameField.getText(), passwordField.getText(), confirmPasswordField.getText()));

        vbox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, confirmPasswordLabel, confirmPasswordField, signupButton);
        return vbox;
    }

    private VBox createChatBox() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(20));

        // Add chat UI elements
        TextArea chatArea = new TextArea();
        chatArea.setEditable(false);

        TextField messageField = new TextField();

        Button sendButton = new Button("Send");
        sendButton.setOnAction(e -> sendMessage(messageField.getText()));

        Button saveButton = new Button("Save Chat Log");
        saveButton.setOnAction(e -> saveChatLog(chatArea.getText()));

        HBox availabilityBox = new HBox();
        availabilityBox.setSpacing(10);

        Label availabilityLabel = new Label("Availability:");

        RadioButton availableRadioButton = new RadioButton("Available");
        availableRadioButton.setOnAction(e -> setAvailabilityStatus(availableRadioButton.isSelected(), chatArea));

        RadioButton busyRadioButton = new RadioButton("Busy");
        busyRadioButton.setOnAction(e -> setAvailabilityStatus(!busyRadioButton.isSelected(), chatArea));

        ToggleGroup toggleGroup = new ToggleGroup();
        availableRadioButton.setToggleGroup(toggleGroup);
        busyRadioButton.setToggleGroup(toggleGroup);

        availabilityBox.getChildren().addAll(availabilityLabel, availableRadioButton, busyRadioButton);

        vbox.getChildren().addAll(chatArea, messageField, sendButton, saveButton, availabilityBox);
        return vbox;
    }

    private void setAvailabilityStatus(boolean available, TextArea chatArea) {
        String statusMessage = available ? "You are now available." : "You are now busy.";
        appendToChatArea(statusMessage);
        String circleColor = available ? "green" : "red";
        String circleHtml = "<div style='width: 10px; height: 10px; background-color: " + circleColor + "; border-radius: 50%; display: inline-block;'></div>";
        Platform.runLater(() -> {
            chatArea.appendText(circleHtml + "\n");
        });
    }

    private void handleLogin(String username, String password) {
        // Send the login data to the server
        output.println("LOGIN:" + username + ":" + password);

        // Wait for the server response
        try {
            String response = input.readLine();
            System.out.println("Server response: " + response);

            if (response.equals("LOGIN_SUCCESS")) {
                // Login successful, switch to chat view
                Platform.runLater(() -> {
                    primaryStage.setScene(new Scene(chatBox, 400, 300));
                    primaryStage.setTitle("Chat");
                });
                startMessageReceiver();
            } else if (response.equals("LOGIN_FAILED")) {
                // Login failed, display an error message
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Login failed. Please check your username and password.");
                    alert.showAndWait();
                });
            } else {
                // Unexpected response from the server
                System.err.println("Unexpected server response: " + response);
            }
        } catch (IOException e) {
            System.err.println("Error reading server response: " + e.getMessage());
        }
    }

    private void handleSignup(String username, String password, String confirmPassword) {
        if (!password.equals(confirmPassword)) {
            System.out.println("Password and Confirm Password do not match.");
            return;
        }

        // Send the signup data to the server
        output.println("SIGNUP:" + username + ":" + password);

        // Wait for the server response
        try {
            String response = input.readLine();
            System.out.println("Server response: " + response);

            if (response.equals("SIGNUP_SUCCESS")) {
                // Signup successful, switch to chat view
                primaryStage.setScene(new Scene(chatBox, 400, 300));
                primaryStage.setTitle("Chat");
                startMessageReceiver();
            } else {
                // Signup failed, display an error message
                Alert alert = new Alert(Alert.AlertType.ERROR, "Signup failed. Please choose a different username.");
                alert.showAndWait();
            }
        } catch (IOException e) {
            System.err.println("Error reading server response: " + e.getMessage());
        }
    }

    private void sendMessage(String message) {
        output.println("MESSAGE:" + message);
    }

    private void startMessageReceiver() {
        // Start a background thread to receive messages from the server
        Thread messageReceiverThread = new Thread(() -> {
            try {
                String message;
                while ((message = input.readLine()) != null) {
                    // Append the received message to the chat area
                    appendToChatArea(message);
                }
            } catch (IOException e) {
                System.err.println("Error reading messages from the server: " + e.getMessage());
            }
        });

        messageReceiverThread.start();
    }

    private void appendToChatArea(String message) {
        // Run the UI update on the JavaFX application thread
        Platform.runLater(() -> {
            TextArea chatArea = (TextArea) chatBox.getChildren().get(0);
            chatArea.appendText(message + "\n");

            // Scroll to the bottom of the chat area
            chatArea.setScrollTop(Double.MAX_VALUE);
        });
    }

    private void saveChatLog(String chatLog) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String filename = "chatlog_" + now.format(formatter) + ".txt";

        try (PrintWriter writer = new PrintWriter(filename)) {
            writer.write(chatLog);
            System.out.println("Chat log saved to file: " + filename);
        } catch (IOException e) {
            System.err.println("Error saving chat log: " + e.getMessage());
        }
    }
}
