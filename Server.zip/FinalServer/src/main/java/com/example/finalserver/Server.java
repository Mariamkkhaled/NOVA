package com.example.finalserver;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Server extends Application {

    private static final int SERVER_PORT = 8880;
    private static final String DB_URL = "jdbc:mysql://localhost/connect";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    private TextArea logTextArea;
    private ListView<String> onlineUsersListView;
    private ObservableList<String> onlineUsers;

    private List<PrintWriter> clientWriters;
    private List<Socket> clientSockets;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Server");
        logTextArea = new TextArea();
        logTextArea.setEditable(false);
        onlineUsers = FXCollections.observableArrayList();
        onlineUsersListView = new ListView<>(onlineUsers);
        VBox root = new VBox(logTextArea, onlineUsersListView);
        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Start the server socket on a separate thread
        new Thread(this::startServer).start();
    }

    private void startServer() {
        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            appendToLog("Connected to the database!");

            // Create a ServerSocket to listen for client connections
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            appendToLog("Server listening on port " + SERVER_PORT);

            clientWriters = new ArrayList<>();
            clientSockets = new ArrayList<>();

            // Accept client connections and handle them in separate threads
            while (true) {
                Socket clientSocket = serverSocket.accept();
                appendToLog("Client connected: " + clientSocket.getInetAddress().getHostAddress());

                // Create a new PrintWriter for this client
                PrintWriter clientWriter = new PrintWriter(clientSocket.getOutputStream(), true);
                clientWriters.add(clientWriter);
                clientSockets.add(clientSocket);

                // Handle client connection in a separate thread
                new Thread(() -> handleClient(clientSocket, connection, clientWriter)).start();
            }
        } catch (SQLException e) {
            appendToLog("Failed to connect to the database: " + e.getMessage());
        } catch (IOException e) {
            appendToLog("Error starting the server: " + e.getMessage());
        }
    }

    private void appendToLog(String message) {
        Platform.runLater(() -> logTextArea.appendText(message + "\n"));
    }

    private void handleClient(Socket clientSocket, Connection connection, PrintWriter clientWriter) {
        try {
            // Set up communication streams with the client
            BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // Read client messages and handle them
            String clientMessage;
            while ((clientMessage = input.readLine()) != null) {
                // Handle client messages here
                appendToLog("Received from client: " + clientMessage);

                // Example: Check login credentials in the database
                String[] messageParts = clientMessage.split(":");
                if (messageParts.length >= 2) {
                    if (messageParts[0].equals("LOGIN")) {
                        String username = messageParts[1];
                        String password = messageParts.length >= 3 ? messageParts[2] : "";
                        boolean loginSuccessful = checkLoginCredentials(connection, username, password);
                        if (loginSuccessful) {
                            clientWriter.println("LOGIN_SUCCESS");
                            addOnlineUser(username);
                        } else {
                            clientWriter.println("LOGIN_FAILED");
                        }
                    } else if (messageParts[0].equals("SIGNUP")) {
                        String username = messageParts[1];
                        String password = messageParts.length >= 3 ? messageParts[2] : "";
                        boolean signupSuccessful = createAccount(connection, username, password);
                        if (signupSuccessful) {
                            clientWriter.println("SIGNUP_SUCCESS");
                            addOnlineUser(username);
                        } else {
                            clientWriter.println("SIGNUP_FAILED");
                        }
                    } else if (messageParts[0].equals("MESSAGE")) {
                        String username = messageParts[1];
                        String message = messageParts.length >= 3 ? messageParts[2] : "";
                        // Broadcast the message to all connected clients
                        broadcastMessage(username, message);
                    }
                }
            }

            // Client has disconnected
            appendToLog("Client disconnected: " + clientSocket.getInetAddress().getHostAddress());
            removeOnlineUser(clientSocket);
            clientWriter.close();
            input.close();
            clientSocket.close();
        } catch (IOException e) {
            appendToLog("Error handling client: " + e.getMessage());
        }
    }

    private boolean checkLoginCredentials(Connection connection, String username, String password) {
        // Example: Check login credentials in the database
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            appendToLog("Error checking login credentials: " + e.getMessage());
            return false;
        }
    }

    private boolean createAccount(Connection connection, String username, String password) {
        // Example: Create an account in the database
        String query = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);
            int affectedRows = statement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            appendToLog("Error creating account: " + e.getMessage());
            return false;
        }
    }

    private void broadcastMessage(String username, String message) {
        // Send the message to all connected clients
        for (PrintWriter writer : clientWriters) {
            writer.println(username + ":" + message);
        }
    }

    private void addOnlineUser(String username) {
        synchronized (onlineUsers) {
            Platform.runLater(() -> onlineUsers.add(username));
        }
    }

    private void removeOnlineUser(Socket clientSocket) {
        synchronized (onlineUsers) {
            int index = clientSockets.indexOf(clientSocket);
            if (index != -1) {
                Platform.runLater(() -> onlineUsers.remove(index));
                clientSockets.remove(index);
                clientWriters.remove(index);
            }
        }
    }
}
